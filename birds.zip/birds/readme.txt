1. extract ''text.zip'' to ''text''

2. Dowload and extract the bird images and extract it to ''CUB-200-2011'':
     http://www.vision.caltech.edu/visipedia/CUB-200-2011.html

3. [Optional] If you want to use the per-trained models, please download the dictionary, “captions.pickle”.
